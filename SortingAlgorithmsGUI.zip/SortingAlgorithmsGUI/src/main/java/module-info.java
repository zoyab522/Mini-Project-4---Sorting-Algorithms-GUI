module com.mycompany.sortingalgorithmsgui {
    requires javafx.controls;
    exports com.mycompany.sortingalgorithmsgui;
}
